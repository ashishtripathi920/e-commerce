/**
 * router.jsx – createBrowserRouter with lazy-loaded page routes
 * All pages are React.lazy() loaded for code splitting
 */
import { createBrowserRouter } from 'react-router-dom';
import { lazy, Suspense } from 'react';

// ── Lazy imports ──────────────────────────────────────────
const Home          = lazy(() => import('../pages/Home/Home'));
const ProductDetail = lazy(() => import('../pages/ProductDetail/ProductDetail'));
const Cart          = lazy(() => import('../pages/Cart/Cart'));
const Checkout      = lazy(() => import('../pages/Checkout/Checkout'));
const NotFound      = lazy(() => import('../pages/NotFound/NotFound'));

// ── Fallback UI while lazy chunk loads ────────────────────
function PageLoader() {
  return (
    <div style={{
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      minHeight: '100vh',
      flexDirection: 'column',
      gap: '1rem',
    }}>
      <div style={{
        width: 48,
        height: 48,
        border: '4px solid hsl(220 14% 91%)',
        borderTopColor: 'hsl(222 89% 55%)',
        borderRadius: '50%',
        animation: 'spin 0.8s linear infinite',
      }} />
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      <p style={{ color: 'hsl(220 9% 46%)', fontSize: '0.9rem' }}>Loading…</p>
    </div>
  );
}

// ── Wrapper with Suspense ─────────────────────────────────
function Wrap({ Page }) {
  return (
    <Suspense fallback={<PageLoader />}>
      <Page />
    </Suspense>
  );
}

// ── Router ────────────────────────────────────────────────
const router = createBrowserRouter([
  {
    path: '/',
    element: <Wrap Page={Home} />,
  },
  {
    path: '/product/:id',
    element: <Wrap Page={ProductDetail} />,
  },
  {
    path: '/cart',
    element: <Wrap Page={Cart} />,
  },
  {
    path: '/checkout',
    element: <Wrap Page={Checkout} />,
  },
  {
    path: '*',
    element: <Wrap Page={NotFound} />,
  },
]);

export default router;
