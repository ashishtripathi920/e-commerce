/**
 * searchSlice.js – Redux slice for managing search query and category filtering
 * 
 * Used across Header and ProductList for real-time filtering.
 */
import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  query: '',
  selectedCategory: 'all',
  sortBy: 'featured',
};

const searchSlice = createSlice({
  name: 'search',
  initialState,
  reducers: {
    /** Sets the text search query */
    setSearch(state, action) {
      state.query = action.payload;
    },
    /** Sets the active category filter */
    setCategory(state, action) {
      state.selectedCategory = action.payload;
    },
    /** Sets the product sort order (e.g. price-low, price-high, rating) */
    setSortBy(state, action) {
      state.sortBy = action.payload;
    },
    /** Resets all filters */
    resetFilters(state) {
      state.query = '';
      state.selectedCategory = 'all';
      state.sortBy = 'featured';
    },
  },
});

export const { setSearch, setCategory, setSortBy, resetFilters } = searchSlice.actions;

// ── Selectors ──────────────────────────────────────────────
export const selectSearchQuery = (state) => state.search.query;
export const selectSelectedCategory = (state) => state.search.selectedCategory;
export const selectSortBy = (state) => state.search.sortBy;

export default searchSlice.reducer;
