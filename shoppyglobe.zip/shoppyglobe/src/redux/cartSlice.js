/**
 * cartSlice.js – Redux slice for shopping cart state management
 * 
 * Features:
 * - Tracks cart items [{ id, title, price, image, quantity }]
 * - Actions: addToCart, removeFromCart, increaseQuantity, decreaseQuantity, clearCart
 * - Enforces business rule: quantity cannot go below 1
 * - Selectors: selectCartItems, selectCartCount, selectCartTotal
 * - Safely syncs with localStorage for persistence across reloads
 */
import { createSlice } from '@reduxjs/toolkit';

// Safely load cart items from localStorage if available
const loadInitialCart = () => {
  try {
    const saved = localStorage.getItem('shoppyglobe_cart');
    return saved ? JSON.parse(saved) : [];
  } catch (err) {
    console.warn('Could not read cart from localStorage:', err);
    return [];
  }
};

// Safely persist cart items to localStorage
const saveCartToStorage = (items) => {
  try {
    localStorage.setItem('shoppyglobe_cart', JSON.stringify(items));
  } catch (err) {
    console.warn('Could not save cart to localStorage:', err);
  }
};

const initialState = {
  items: loadInitialCart(),
};

const cartSlice = createSlice({
  name: 'cart',
  initialState,
  reducers: {
    /**
     * Add a product to the cart. If already present, increment quantity.
     * @param {Object} action.payload - Product object { id, title, price, thumbnail, ... }
     */
    addToCart(state, action) {
      const product = action.payload;
      const existing = state.items.find((i) => i.id === product.id);
      if (existing) {
        existing.quantity += (product.quantity || 1);
      } else {
        state.items.push({
          id: product.id,
          title: product.title,
          price: product.price,
          image: product.thumbnail || product.images?.[0] || '',
          category: product.category,
          quantity: product.quantity || 1,
        });
      }
      saveCartToStorage(state.items);
    },

    /**
     * Remove an item completely from the cart by its ID.
     * @param {number|string} action.payload - Product ID
     */
    removeFromCart(state, action) {
      state.items = state.items.filter((i) => i.id !== action.payload);
      saveCartToStorage(state.items);
    },

    /**
     * Increase the quantity of a product by 1.
     * @param {number|string} action.payload - Product ID
     */
    increaseQuantity(state, action) {
      const item = state.items.find((i) => i.id === action.payload);
      if (item) {
        item.quantity += 1;
        saveCartToStorage(state.items);
      }
    },

    /**
     * Decrease the quantity of a product by 1.
     * Enforces the constraint that quantity cannot go below 1.
     * @param {number|string} action.payload - Product ID
     */
    decreaseQuantity(state, action) {
      const item = state.items.find((i) => i.id === action.payload);
      if (item && item.quantity > 1) {
        item.quantity -= 1;
        saveCartToStorage(state.items);
      }
    },

    /**
     * Clear all items in the cart (e.g. after successful checkout).
     */
    clearCart(state) {
      state.items = [];
      saveCartToStorage([]);
    },
  },
});

export const {
  addToCart,
  removeFromCart,
  increaseQuantity,
  decreaseQuantity,
  clearCart,
} = cartSlice.actions;

// ── Selectors ──────────────────────────────────────────────
/** Returns all items in the cart */
export const selectCartItems = (state) => state.cart.items;

/** Returns total number of individual product units in cart */
export const selectCartCount = (state) =>
  state.cart.items.reduce((sum, item) => sum + item.quantity, 0);

/** Returns cumulative total price of all items in cart */
export const selectCartTotal = (state) =>
  state.cart.items.reduce((sum, item) => sum + item.price * item.quantity, 0);

export default cartSlice.reducer;
