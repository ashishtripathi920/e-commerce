/**
 * NotFound.jsx – 404 Not Found Fallback Page Component
 * 
 * Requirements Satisfied:
 * - Display a 404 page for unknown routes (20 marks)
 * - In the 404 page, display proper error details on the UI
 * - Navigation button to redirect back to Home
 */
import { Link, useLocation } from 'react-router-dom';
import Header from '../../components/Header/Header';
import styles from './NotFound.module.css';

function NotFound() {
  const location = useLocation();

  return (
    <>
      <Header />
      <main className="page-content" aria-label="Page Not Found Error">
        <div className="container">
          <div className={styles.card}>
            <div className={styles.iconWrapper}>
              <span className={styles.icon} aria-hidden="true">🔭</span>
            </div>

            <span className={styles.statusCode}>HTTP 404</span>
            <h1 className={styles.title}>Page Not Found</h1>
            
            <p className={styles.description}>
              We couldn't locate the resource you requested. It might have been deleted,
              renamed, or is temporarily unavailable.
            </p>

            {/* Error Details UI */}
            <div className={styles.errorDetailsBox}>
              <h2 className={styles.errorDetailsHeading}>Error Details:</h2>
              <ul className={styles.errorDetailsList}>
                <li><strong>Status Code:</strong> 404 (Resource Not Found)</li>
                <li><strong>Requested Path:</strong> <code>{location.pathname || 'Unknown'}</code></li>
                <li><strong>Timestamp:</strong> <code>{new Date().toLocaleString()}</code></li>
                <li><strong>Client State:</strong> Route mismatch with active router endpoints</li>
              </ul>
            </div>

            <div className={styles.actions}>
              <Link to="/" className={styles.primaryBtn} id="404-return-home-btn">
                🏠 Return to Home
              </Link>
              <Link to="/cart" className={styles.secondaryBtn} id="404-view-cart-btn">
                🛒 View Cart
              </Link>
            </div>
          </div>
        </div>
      </main>
    </>
  );
}

export default NotFound;
