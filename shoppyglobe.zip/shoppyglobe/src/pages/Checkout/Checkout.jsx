/**
 * Checkout.jsx – Checkout Page Component (/checkout)
 * 
 * Requirements Satisfied:
 * - Create dummy form to collect user details (Name, Email, Phone, Address, City, State, PIN Code, Payment method)
 * - Display summary of products added to the cart in Indian Rupees (₹)
 * - Include "Place Order" button
 * - Upon clicking: validates form with Indian phone & PIN validation, displays "Order placed" message,
 *   empties the cart, and redirects user back to Home automatically
 */
import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { clearCart, selectCartItems, selectCartTotal } from '../../redux/cartSlice';
import { useToast } from '../../components/Toast/Toast';
import Header from '../../components/Header/Header';
import {
  formatDirectINR,
  getINRAmount,
  FREE_SHIPPING_THRESHOLD_INR,
  STANDARD_SHIPPING_INR,
  GST_RATE,
  formatINR,
} from '../../utils/currency';
import styles from './Checkout.module.css';

const INDIAN_STATES = [
  'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chhattisgarh',
  'Delhi (NCR)', 'Goa', 'Gujarat', 'Haryana', 'Himachal Pradesh',
  'Jharkhand', 'Karnataka', 'Kerala', 'Madhya Pradesh', 'Maharashtra',
  'Manipur', 'Meghalaya', 'Mizoram', 'Nagaland', 'Odisha',
  'Punjab', 'Rajasthan', 'Sikkim', 'Tamil Nadu', 'Telangana',
  'Tripura', 'Uttar Pradesh', 'Uttarakhand', 'West Bengal',
];

const INITIAL_FORM = {
  name: '',
  email: '',
  phone: '',
  address: '',
  city: '',
  state: 'Maharashtra',
  postalCode: '',
  paymentMethod: 'upi',
};

const INITIAL_ERRORS = {
  name: '',
  email: '',
  phone: '',
  address: '',
  city: '',
  state: '',
  postalCode: '',
};

function Checkout() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const toast = useToast();
  const items = useSelector(selectCartItems);
  const totalUSD = useSelector(selectCartTotal);

  const [form, setForm] = useState(INITIAL_FORM);
  const [errors, setErrors] = useState(INITIAL_ERRORS);
  const [orderPlaced, setOrderPlaced] = useState(false);
  const [countdown, setCountdown] = useState(4);
  const [placedOrderDetails, setPlacedOrderDetails] = useState(null);

  // Financial calculations in Indian Rupees (INR)
  const subtotalINR = getINRAmount(totalUSD);
  const gstINR = subtotalINR * GST_RATE;
  const shippingINR = subtotalINR >= FREE_SHIPPING_THRESHOLD_INR || subtotalINR === 0 ? 0 : STANDARD_SHIPPING_INR;
  const grandTotalINR = subtotalINR + gstINR + shippingINR;

  // Auto redirect countdown after order is placed
  useEffect(() => {
    if (!orderPlaced) return;

    if (countdown <= 0) {
      navigate('/');
      return;
    }

    const timer = setTimeout(() => {
      setCountdown((prev) => prev - 1);
    }, 1000);

    return () => clearTimeout(timer);
  }, [orderPlaced, countdown, navigate]);

  // Form validation (Adapted for Indian Region)
  const validateForm = () => {
    const errs = { ...INITIAL_ERRORS };
    let isValid = true;

    if (!form.name.trim()) {
      errs.name = 'Full name is required';
      isValid = false;
    }

    if (!form.email.trim()) {
      errs.email = 'Email address is required';
      isValid = false;
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) {
      errs.email = 'Please enter a valid email address';
      isValid = false;
    }

    // Indian mobile phone number: 10 digits (optionally prefixed with +91 or 0)
    if (!form.phone.trim()) {
      errs.phone = 'Phone number is required';
      isValid = false;
    } else if (!/^(?:\+91|0)?[6-9]\d{9}$/.test(form.phone.replace(/[\s-]/g, ''))) {
      errs.phone = 'Enter valid 10-digit Indian mobile number (e.g., 9876543210)';
      isValid = false;
    }

    if (!form.address.trim()) {
      errs.address = 'Flat / House No. & Street address is required';
      isValid = false;
    }

    if (!form.city.trim()) {
      errs.city = 'City / Town is required';
      isValid = false;
    }

    // Indian 6-digit PIN code
    if (!form.postalCode.trim()) {
      errs.postalCode = '6-digit PIN code is required';
      isValid = false;
    } else if (!/^[1-9][0-9]{5}$/.test(form.postalCode.trim())) {
      errs.postalCode = 'Enter a valid 6-digit Indian PIN code (e.g. 400001)';
      isValid = false;
    }

    setErrors(errs);
    return isValid;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: '' }));
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!validateForm()) {
      toast.error('Please fill all delivery details correctly.');
      return;
    }

    // Save order details for confirmation display
    setPlacedOrderDetails({
      customerName: form.name,
      address: `${form.address}, ${form.city}, ${form.state} - ${form.postalCode}`,
      paymentMethod: form.paymentMethod,
      totalAmountINR: grandTotalINR,
      itemCount: items.reduce((s, i) => s + i.quantity, 0),
    });

    // 1. Empty the cart in Redux store
    dispatch(clearCart());

    // 2. Set order placed state to display confirmation message
    setOrderPlaced(true);

    // 3. Show instant feedback toast
    toast.success('Order placed! Redirecting to home...');
  };

  // ── Success State Overlay (When Order is Placed) ───────────
  if (orderPlaced) {
    return (
      <>
        <Header />
        <main className="page-content" aria-label="Order Placed Successfully">
          <div className="container">
            <div className={styles.successCard}>
              <div className={styles.successIconWrapper}>
                <span className={styles.successIcon} aria-hidden="true">🎉</span>
              </div>
              <h1 className={styles.successTitle}>Order placed!</h1>
              <p className={styles.successSub}>
                Thank you for shopping with ShoppyGlobe, <strong>{placedOrderDetails?.customerName}</strong>!
                Your order is confirmed and will be delivered to:
              </p>
              <div className={styles.addressBox}>
                📍 <strong>{placedOrderDetails?.address}</strong>
              </div>

              <div className={styles.orderSummarySnippet}>
                <span>Total Amount: <strong>{formatDirectINR(placedOrderDetails?.totalAmountINR)}</strong></span>
                <span>Payment Mode: <strong style={{ textTransform: 'uppercase' }}>{placedOrderDetails?.paymentMethod}</strong></span>
              </div>

              <div className={styles.countdownBox}>
                <p className={styles.countdownText}>
                  Redirecting back to Home page in <strong>{countdown}</strong> second{countdown !== 1 ? 's' : ''}...
                </p>
                <div className={styles.countdownProgress}>
                  <div
                    className={styles.countdownBar}
                    style={{ width: `${((4 - countdown) / 4) * 100}%` }}
                  />
                </div>
              </div>

              <button
                type="button"
                className={styles.manualHomeBtn}
                onClick={() => navigate('/')}
                id="order-placed-manual-home-btn"
              >
                🏠 Return to Home Now
              </button>
            </div>
          </div>
        </main>
      </>
    );
  }

  // ── Empty Cart Guard ──────────────────────────────────────
  if (items.length === 0) {
    return (
      <>
        <Header />
        <main className="page-content">
          <div className="container">
            <div className={styles.emptyCartCard}>
              <span className={styles.emptyIcon}>🛒</span>
              <h2>Your Cart is Empty</h2>
              <p>You cannot proceed to checkout with an empty cart.</p>
              <Link to="/" className={styles.shopLink}>Browse Products</Link>
            </div>
          </div>
        </main>
      </>
    );
  }

  return (
    <>
      <Header />
      <main className="page-content" aria-label="Checkout">
        <div className="container">
          <div className={styles.page}>
            <div className={styles.pageHeader}>
              <h1 className={styles.pageTitle}>Secure Checkout</h1>
              <p className={styles.pageSubtitle}>Complete your delivery details (India Region)</p>
            </div>

            <div className={styles.layout}>
              {/* ── Checkout Details Form ── */}
              <form onSubmit={handleSubmit} className={styles.form} noValidate>
                {/* 1. Contact Info */}
                <div className={styles.formSection}>
                  <h2 className={styles.sectionHeading}>1. Contact Details</h2>
                  <div className={styles.formGrid}>
                    <div className={styles.formGroup}>
                      <label htmlFor="checkout-name" className={styles.label}>
                        Full Name <span className={styles.req}>*</span>
                      </label>
                      <input
                        id="checkout-name"
                        name="name"
                        type="text"
                        placeholder="Ashish Sharma"
                        value={form.name}
                        onChange={handleChange}
                        className={`${styles.input} ${errors.name ? styles.inputError : ''}`}
                        autoComplete="name"
                      />
                      {errors.name && <span className={styles.errorText}>{errors.name}</span>}
                    </div>

                    <div className={styles.formGroup}>
                      <label htmlFor="checkout-email" className={styles.label}>
                        Email Address <span className={styles.req}>*</span>
                      </label>
                      <input
                        id="checkout-email"
                        name="email"
                        type="email"
                        placeholder="ashish@example.com"
                        value={form.email}
                        onChange={handleChange}
                        className={`${styles.input} ${errors.email ? styles.inputError : ''}`}
                        autoComplete="email"
                      />
                      {errors.email && <span className={styles.errorText}>{errors.email}</span>}
                    </div>

                    <div className={styles.formGroup}>
                      <label htmlFor="checkout-phone" className={styles.label}>
                        Mobile Number <span className={styles.req}>*</span>
                      </label>
                      <input
                        id="checkout-phone"
                        name="phone"
                        type="tel"
                        placeholder="9876543210"
                        value={form.phone}
                        onChange={handleChange}
                        className={`${styles.input} ${errors.phone ? styles.inputError : ''}`}
                        autoComplete="tel"
                      />
                      {errors.phone && <span className={styles.errorText}>{errors.phone}</span>}
                    </div>
                  </div>
                </div>

                {/* 2. Shipping Address (India) */}
                <div className={styles.formSection}>
                  <h2 className={styles.sectionHeading}>2. Delivery Address (India)</h2>
                  <div className={styles.formGrid}>
                    <div className={`${styles.formGroup} ${styles.fullWidth}`}>
                      <label htmlFor="checkout-address" className={styles.label}>
                        Flat, House no., Building, Street <span className={styles.req}>*</span>
                      </label>
                      <input
                        id="checkout-address"
                        name="address"
                        type="text"
                        placeholder="Flat 402, Sunshine Heights, Linking Road"
                        value={form.address}
                        onChange={handleChange}
                        className={`${styles.input} ${errors.address ? styles.inputError : ''}`}
                        autoComplete="street-address"
                      />
                      {errors.address && <span className={styles.errorText}>{errors.address}</span>}
                    </div>

                    <div className={styles.formGroup}>
                      <label htmlFor="checkout-city" className={styles.label}>
                        City / District <span className={styles.req}>*</span>
                      </label>
                      <input
                        id="checkout-city"
                        name="city"
                        type="text"
                        placeholder="Mumbai"
                        value={form.city}
                        onChange={handleChange}
                        className={`${styles.input} ${errors.city ? styles.inputError : ''}`}
                        autoComplete="address-level2"
                      />
                      {errors.city && <span className={styles.errorText}>{errors.city}</span>}
                    </div>

                    <div className={styles.formGroup}>
                      <label htmlFor="checkout-state" className={styles.label}>
                        State <span className={styles.req}>*</span>
                      </label>
                      <select
                        id="checkout-state"
                        name="state"
                        value={form.state}
                        onChange={handleChange}
                        className={styles.input}
                      >
                        {INDIAN_STATES.map((st) => (
                          <option key={st} value={st}>{st}</option>
                        ))}
                      </select>
                    </div>

                    <div className={styles.formGroup}>
                      <label htmlFor="checkout-postal" className={styles.label}>
                        PIN Code <span className={styles.req}>*</span>
                      </label>
                      <input
                        id="checkout-postal"
                        name="postalCode"
                        type="text"
                        placeholder="400050"
                        maxLength={6}
                        value={form.postalCode}
                        onChange={handleChange}
                        className={`${styles.input} ${errors.postalCode ? styles.inputError : ''}`}
                        autoComplete="postal-code"
                      />
                      {errors.postalCode && <span className={styles.errorText}>{errors.postalCode}</span>}
                    </div>
                  </div>
                </div>

                {/* 3. Payment Method (India Popular) */}
                <div className={styles.formSection}>
                  <h2 className={styles.sectionHeading}>3. Payment Method</h2>
                  <div className={styles.paymentOptions}>
                    <label className={`${styles.paymentRadio} ${form.paymentMethod === 'upi' ? styles.paymentActive : ''}`}>
                      <input
                        type="radio"
                        name="paymentMethod"
                        value="upi"
                        checked={form.paymentMethod === 'upi'}
                        onChange={handleChange}
                      />
                      <span>📱 UPI (Google Pay / PhonePe / Paytm / BHIM)</span>
                    </label>

                    <label className={`${styles.paymentRadio} ${form.paymentMethod === 'card' ? styles.paymentActive : ''}`}>
                      <input
                        type="radio"
                        name="paymentMethod"
                        value="card"
                        checked={form.paymentMethod === 'card'}
                        onChange={handleChange}
                      />
                      <span>💳 Debit / Credit Card (RuPay / Visa / MasterCard)</span>
                    </label>

                    <label className={`${styles.paymentRadio} ${form.paymentMethod === 'netbanking' ? styles.paymentActive : ''}`}>
                      <input
                        type="radio"
                        name="paymentMethod"
                        value="netbanking"
                        checked={form.paymentMethod === 'netbanking'}
                        onChange={handleChange}
                      />
                      <span>🏦 Net Banking (SBI, HDFC, ICICI, Axis, etc.)</span>
                    </label>

                    <label className={`${styles.paymentRadio} ${form.paymentMethod === 'cod' ? styles.paymentActive : ''}`}>
                      <input
                        type="radio"
                        name="paymentMethod"
                        value="cod"
                        checked={form.paymentMethod === 'cod'}
                        onChange={handleChange}
                      />
                      <span>💵 Cash on Delivery (COD)</span>
                    </label>
                  </div>
                </div>

                {/* Place Order Button */}
                <button
                  type="submit"
                  className={styles.placeBtn}
                  id="place-order-btn"
                >
                  🎉 Place Order — {formatDirectINR(grandTotalINR)}
                </button>
              </form>

              {/* ── Order Summary Sidebar ── */}
              <aside className={styles.summaryCard} aria-label="Order Summary">
                <h2 className={styles.summaryTitle}>Order Summary ({items.length} item{items.length !== 1 ? 's' : ''})</h2>

                <div className={styles.summaryItems}>
                  {items.map((item) => (
                    <div key={item.id} className={styles.summaryItem}>
                      <img
                        src={item.image}
                        alt={item.title}
                        className={styles.summaryImg}
                        loading="lazy"
                      />
                      <div className={styles.summaryItemInfo}>
                        <p className={styles.summaryItemTitle}>{item.title}</p>
                        <p className={styles.summaryItemMeta}>Qty: {item.quantity} × {formatINR(item.price)}</p>
                      </div>
                      <span className={styles.summaryItemPrice}>
                        {formatINR(item.price * item.quantity)}
                      </span>
                    </div>
                  ))}
                </div>

                <hr className={styles.divider} />

                <div className={styles.breakdown}>
                  <div className={styles.breakdownRow}>
                    <span>Items Subtotal</span>
                    <span>{formatDirectINR(subtotalINR)}</span>
                  </div>
                  <div className={styles.breakdownRow}>
                    <span>Delivery Charges</span>
                    <span>{shippingINR === 0 ? 'FREE' : formatDirectINR(shippingINR)}</span>
                  </div>
                  <div className={styles.breakdownRow}>
                    <span>Estimated GST (18%)</span>
                    <span>{formatDirectINR(gstINR)}</span>
                  </div>
                </div>

                <div className={styles.totalRow}>
                  <span className={styles.totalLabel}>Total Due</span>
                  <span className={styles.totalAmt}>{formatDirectINR(grandTotalINR)}</span>
                </div>
              </aside>
            </div>
          </div>
        </div>
      </main>
    </>
  );
}

export default Checkout;
