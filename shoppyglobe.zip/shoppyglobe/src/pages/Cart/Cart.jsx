/**
 * Cart.jsx – Shopping Cart Page (/cart)
 * 
 * Requirements Satisfied:
 * - Displays all cart items with options to adjust quantities or remove (20 marks)
 * - Renders list of cart items using unique key (10 marks)
 * - Uses Redux selectors (selectCartItems, selectCartTotal, selectCartCount) (50 marks)
 * - Order summary breakdown in Indian Rupees (₹) (subtotal, shipping, GST, total)
 * - Links to Checkout page (/checkout)
 */
import { useSelector, useDispatch } from 'react-redux';
import { Link } from 'react-router-dom';
import {
  selectCartItems,
  selectCartTotal,
  selectCartCount,
  clearCart,
} from '../../redux/cartSlice';
import CartItem from '../../components/CartItem/CartItem';
import Header from '../../components/Header/Header';
import { useToast } from '../../components/Toast/Toast';
import {
  formatINR,
  formatDirectINR,
  getINRAmount,
  FREE_SHIPPING_THRESHOLD_INR,
  STANDARD_SHIPPING_INR,
  GST_RATE,
} from '../../utils/currency';
import styles from './Cart.module.css';

function Cart() {
  const dispatch = useDispatch();
  const toast = useToast();
  const items = useSelector(selectCartItems);
  const totalUSD = useSelector(selectCartTotal);
  const count = useSelector(selectCartCount);

  // Financial calculations in INR
  const subtotalINR = getINRAmount(totalUSD);
  const gstINR = subtotalINR * GST_RATE;
  const shippingINR = subtotalINR >= FREE_SHIPPING_THRESHOLD_INR || subtotalINR === 0 ? 0 : STANDARD_SHIPPING_INR;
  const grandTotalINR = subtotalINR + gstINR + shippingINR;

  const handleClearCart = () => {
    if (window.confirm('Are you sure you want to remove all items from your cart?')) {
      dispatch(clearCart());
      toast.info('Your shopping cart has been cleared.');
    }
  };

  return (
    <>
      <Header />
      <main className="page-content" aria-label="Shopping Cart">
        <div className="container">
          <div className={styles.page}>
            {/* Page Header */}
            <div className={styles.pageHeader}>
              <div>
                <h1 className={styles.pageTitle}>Shopping Cart</h1>
                <p className={styles.pageSubtitle}>
                  {items.length > 0
                    ? `You have ${count} item${count !== 1 ? 's' : ''} in your cart`
                    : 'Your cart is currently empty'}
                </p>
              </div>

              {items.length > 0 && (
                <button
                  type="button"
                  className={styles.clearCartBtn}
                  onClick={handleClearCart}
                  id="clear-entire-cart-btn"
                >
                  Clear Cart
                </button>
              )}
            </div>

            {items.length === 0 ? (
              /* ── Empty Cart State ── */
              <div className={styles.emptyBox}>
                <span className={styles.emptyIcon} aria-hidden="true">🛍️</span>
                <h2 className={styles.emptyTitle}>Your Cart is Empty</h2>
                <p className={styles.emptyMsg}>
                  Looks like you haven't added any items to your shopping cart yet.
                  Explore our wide selection of high quality products!
                </p>
                <Link to="/" className={styles.shopBtn} id="empty-cart-explore-btn">
                  Explore Products
                </Link>
              </div>
            ) : (
              /* ── Active Cart Layout ── */
              <div className={styles.layout}>
                {/* List of Cart Items */}
                <div className={styles.itemsList} role="region" aria-label="Cart items list">
                  {items.map((item) => (
                    <CartItem key={item.id} item={item} />
                  ))}
                </div>

                {/* Sticky Order Summary Sidebar */}
                <aside className={styles.summary} aria-label="Order Summary">
                  <h2 className={styles.summaryTitle}>Order Summary</h2>

                  <div className={styles.summaryRow}>
                    <span>Items Subtotal ({count})</span>
                    <span>{formatDirectINR(subtotalINR)}</span>
                  </div>

                  <div className={styles.summaryRow}>
                    <span>Delivery Charges</span>
                    <span>
                      {shippingINR === 0 ? (
                        <span className={styles.freeBadge}>FREE</span>
                      ) : (
                        formatDirectINR(shippingINR)
                      )}
                    </span>
                  </div>

                  <div className={styles.summaryRow}>
                    <span>Estimated GST (18%)</span>
                    <span>{formatDirectINR(gstINR)}</span>
                  </div>

                  {shippingINR > 0 && (
                    <div className={styles.shippingNotice}>
                      💡 Add <strong>{formatDirectINR(FREE_SHIPPING_THRESHOLD_INR - subtotalINR)}</strong> more to qualify for <strong>FREE Delivery</strong>!
                    </div>
                  )}

                  <hr className={styles.divider} />

                  <div className={styles.totalRow}>
                    <span className={styles.totalLabel}>Estimated Total</span>
                    <span className={styles.totalAmt}>{formatDirectINR(grandTotalINR)}</span>
                  </div>

                  <Link
                    to="/checkout"
                    className={styles.checkoutBtn}
                    id="cart-proceed-checkout-btn"
                  >
                    🔒 Proceed to Checkout
                  </Link>

                  <Link to="/" className={styles.continueBtn} id="cart-continue-shopping-btn">
                    ← Continue Shopping
                  </Link>
                </aside>
              </div>
            )}
          </div>
        </div>
      </main>
    </>
  );
}

export default Cart;
