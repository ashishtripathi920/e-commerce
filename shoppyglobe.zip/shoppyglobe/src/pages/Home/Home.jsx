// Home page – renders hero section + product listing
import Header from '../../components/Header/Header';
import ProductList from '../../components/ProductList/ProductList';
import styles from './Home.module.css';

function Home() {
  return (
    <>
      <Header />
      <main className="page-content">
        {/* Hero */}
        <section className={styles.hero}>
          <div className="container">
            <span className={styles.heroTag}>✨ New Arrivals Every Week</span>
            <h1 className={styles.heroTitle}>
              Shop the World,<br />
              <span className={styles.heroAccent}>Delivered to You</span>
            </h1>
            <p className={styles.heroSub}>
              Discover thousands of products across every category — 
              from electronics to fashion, beauty to home essentials.
            </p>
            <div className={styles.heroStats}>
              <div className={styles.stat}>
                <span className={styles.statNum}>100+</span>
                <span className={styles.statLabel}>Products</span>
              </div>
              <div className={styles.stat}>
                <span className={styles.statNum}>30+</span>
                <span className={styles.statLabel}>Categories</span>
              </div>
              <div className={styles.stat}>
                <span className={styles.statNum}>4.8★</span>
                <span className={styles.statLabel}>Avg. Rating</span>
              </div>
            </div>
          </div>
        </section>

        {/* Products */}
        <section className={styles.products}>
          <div className="container">
            <ProductList />
          </div>
        </section>
      </main>
    </>
  );
}

export default Home;
