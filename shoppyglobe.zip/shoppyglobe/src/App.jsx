// App.jsx – root component: wraps router + toast provider
import { RouterProvider } from 'react-router-dom';
import { ToastProvider } from './components/Toast/Toast';
import router from './router/router';

function App() {
  return (
    <ToastProvider>
      <RouterProvider router={router} />
    </ToastProvider>
  );
}

export default App;
