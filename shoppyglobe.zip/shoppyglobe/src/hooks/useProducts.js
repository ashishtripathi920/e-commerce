/**
 * useProducts.js – Custom React Hook for fetching product data from DummyJSON API
 * 
 * Requirements Satisfied:
 * - Fetches products from 'https://dummyjson.com/products' using useEffect on component mount (20 marks)
 * - Stores fetched data in component/hook state
 * - Graceful error handling for failed network requests (10 marks)
 * - Provides reload/retry capability
 */
import { useState, useEffect, useCallback } from 'react';

const API_URL = 'https://dummyjson.com/products?limit=100';

/**
 * Custom hook to fetch and manage product list state
 * @returns {{ products: Array, loading: boolean, error: string|null, refetch: Function, categories: Array }}
 */
export function useProducts() {
  const [products, setProducts]     = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading]       = useState(true);
  const [error, setError]           = useState(null);

  const fetchProducts = useCallback(async (signal) => {
    try {
      setLoading(true);
      setError(null);

      const response = await fetch(API_URL, { signal });
      if (!response.ok) {
        throw new Error(`Failed to load products (HTTP ${response.status}: ${response.statusText})`);
      }

      const data = await response.json();
      if (data && Array.isArray(data.products)) {
        setProducts(data.products);
        // Extract unique categories for filtering tabs
        const uniqueCategories = [
          ...new Set(data.products.map((p) => p.category).filter(Boolean)),
        ];
        setCategories(uniqueCategories);
      } else {
        throw new Error('Invalid response format received from products API.');
      }
    } catch (err) {
      if (err.name !== 'AbortError') {
        setError(err.message || 'An unexpected error occurred while fetching products.');
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    const controller = new AbortController();
    fetchProducts(controller.signal);

    // Cleanup: abort fetch on component unmount
    return () => {
      controller.abort();
    };
  }, [fetchProducts]);

  return {
    products,
    categories,
    loading,
    error,
    refetch: () => fetchProducts(),
  };
}

export default useProducts;
