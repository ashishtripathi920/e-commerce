/**
 * currency.js – Currency formatting utility for Indian Rupee (INR / ₹)
 * 
 * Converts USD base prices from DummyJSON API to Indian Rupees (INR)
 * using the standard conversion rate and formats numbers using Indian numbering system (Lakhs / Crores).
 */

// Exchange rate: 1 USD = 83 INR
export const USD_TO_INR = 83;

// Indian shipping & tax configuration
export const FREE_SHIPPING_THRESHOLD_INR = 999; // Free delivery above ₹999
export const STANDARD_SHIPPING_INR = 99;        // ₹99 standard delivery fee
export const GST_RATE = 0.18;                   // 18% GST standard in India

/**
 * Converts a USD amount to INR value
 * @param {number} usdAmount 
 * @returns {number} INR amount
 */
export function getINRAmount(usdAmount) {
  return (usdAmount || 0) * USD_TO_INR;
}

/**
 * Formats a USD amount as Indian Rupee (₹) currency string
 * Example: 10 -> ₹830, 499.99 -> ₹41,499
 * 
 * @param {number} usdAmount - The raw USD amount from the API
 * @param {Object} [options]
 * @param {number} [options.decimals=0] - Decimal places (defaults to 0 for clean pricing, e.g., ₹799)
 * @returns {string} Formatted Indian Rupee string (e.g., "₹1,499")
 */
export function formatINR(usdAmount, { decimals = 0 } = {}) {
  const inr = getINRAmount(usdAmount);
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: decimals,
    minimumFractionDigits: decimals,
  }).format(inr);
}

/**
 * Formats a direct INR number as currency string
 * @param {number} inrAmount 
 * @param {Object} [options]
 * @returns {string} Formatted string
 */
export function formatDirectINR(inrAmount, { decimals = 0 } = {}) {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: decimals,
    minimumFractionDigits: decimals,
  }).format(inrAmount || 0);
}
