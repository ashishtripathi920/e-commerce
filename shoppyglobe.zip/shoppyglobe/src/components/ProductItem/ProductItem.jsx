/**
 * ProductItem – single product card
 * Props: product (object), onAddToCart (fn)
 */
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { addToCart } from '../../redux/cartSlice';
import { useToast } from '../Toast/Toast';
import { formatINR } from '../../utils/currency';
import styles from './ProductItem.module.css';

// Render star rating visually
function StarRating({ rating }) {
  return (
    <div className={styles.stars} aria-label={`Rating: ${rating} out of 5`}>
      {[1, 2, 3, 4, 5].map((n) => (
        <span
          key={n}
          className={`${styles.star} ${n <= Math.round(rating) ? styles.starFilled : styles.starEmpty}`}
          aria-hidden="true"
        >
          ★
        </span>
      ))}
    </div>
  );
}

// Calculate original price before discount
function getOriginalPrice(price, discountPercentage) {
  return price / (1 - discountPercentage / 100);
}

function ProductItem({ product }) {
  const dispatch   = useDispatch();
  const toast      = useToast();
  const [imgLoaded, setImgLoaded] = useState(false);
  const [added,     setAdded]     = useState(false);

  function handleAddToCart(e) {
    e.preventDefault(); // prevent card link navigation
    e.stopPropagation();
    dispatch(addToCart(product));
    toast.success(`"${product.title.slice(0, 30)}…" added to cart`);
    // Brief green flash on button
    setAdded(true);
    setTimeout(() => setAdded(false), 1200);
  }

  const original = product.discountPercentage > 0
    ? getOriginalPrice(product.price, product.discountPercentage)
    : null;

  return (
    <Link to={`/product/${product.id}`} className={styles.card} id={`product-card-${product.id}`}>
      {/* Product image with lazy loading */}
      <div className={styles.imageWrapper}>
        {!imgLoaded && <div className={`${styles.imageSkeleton} skeleton`} />}
        <img
          src={product.thumbnail}
          alt={product.title}
          className={styles.image}
          loading="lazy"
          onLoad={() => setImgLoaded(true)}
          style={{ opacity: imgLoaded ? 1 : 0, transition: 'opacity 0.3s' }}
        />
        {product.discountPercentage > 0 && (
          <span className={styles.discountBadge}>
            −{Math.round(product.discountPercentage)}%
          </span>
        )}
      </div>

      {/* Card body */}
      <div className={styles.body}>
        <span className={styles.category}>{product.category}</span>
        <h3 className={styles.title}>{product.title}</h3>

        {/* Rating */}
        <div className={styles.ratingRow}>
          <StarRating rating={product.rating} />
          <span className={styles.ratingNum}>({product.rating})</span>
        </div>

        {/* Price in Indian Rupees */}
        <div className={styles.priceRow}>
          <span className={styles.price}>{formatINR(product.price)}</span>
          {original && (
            <span className={styles.originalPrice}>
              {formatINR(original)}
            </span>
          )}
        </div>

        {/* Add to Cart */}
        <button
          className={`${styles.addBtn} ${added ? styles.added : ''}`}
          onClick={handleAddToCart}
          id={`add-to-cart-${product.id}`}
          aria-label={`Add ${product.title} to cart`}
        >
          {added ? '✓ Added!' : '🛒 Add to Cart'}
        </button>
      </div>
    </Link>
  );
}

export default ProductItem;
