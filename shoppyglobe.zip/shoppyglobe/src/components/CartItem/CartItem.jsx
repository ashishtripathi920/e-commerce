/**
 * CartItem.jsx – Single Item Row in Shopping Cart Component
 * 
 * Requirements Satisfied:
 * - Pass data from parent Cart to child CartItem via props (10 marks)
 * - Increase & Decrease quantity buttons, prevented from dropping below 1 (20 marks)
 * - Remove product button dispatched with Redux (20 marks)
 * - Accessible controls and clear unit/subtotal pricing in Indian Rupees (₹)
 */
import { Link } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import {
  removeFromCart,
  increaseQuantity,
  decreaseQuantity,
} from '../../redux/cartSlice';
import { useToast } from '../Toast/Toast';
import { formatINR } from '../../utils/currency';
import styles from './CartItem.module.css';

function CartItem({ item }) {
  const dispatch = useDispatch();
  const toast = useToast();

  const handleRemove = () => {
    dispatch(removeFromCart(item.id));
    toast.error(`Removed "${item.title}" from cart`);
  };

  const handleDecrease = () => {
    if (item.quantity > 1) {
      dispatch(decreaseQuantity(item.id));
    }
  };

  const handleIncrease = () => {
    dispatch(increaseQuantity(item.id));
  };

  return (
    <article className={styles.item} id={`cart-item-${item.id}`} aria-label={`${item.title} in cart`}>
      {/* Product Thumbnail */}
      <Link to={`/product/${item.id}`} className={styles.imageLink} tabIndex={-1}>
        <img
          src={item.image}
          alt={item.title}
          className={styles.image}
          loading="lazy"
        />
      </Link>

      {/* Product Info */}
      <div className={styles.info}>
        {item.category && <span className={styles.category}>{item.category}</span>}
        <Link to={`/product/${item.id}`} className={styles.titleLink}>
          <h3 className={styles.title}>{item.title}</h3>
        </Link>
        <p className={styles.unitPrice}>{formatINR(item.price)} each</p>
      </div>

      {/* Quantity Adjustment Controls */}
      <div className={styles.controls}>
        <div className={styles.quantityRow} role="group" aria-label={`Quantity adjustment for ${item.title}`}>
          <button
            type="button"
            className={styles.qtyBtn}
            onClick={handleDecrease}
            disabled={item.quantity <= 1}
            aria-label={`Decrease quantity of ${item.title}`}
            id={`decrease-qty-${item.id}`}
          >
            −
          </button>
          <span className={styles.quantity} aria-label={`Current quantity: ${item.quantity}`}>
            {item.quantity}
          </span>
          <button
            type="button"
            className={styles.qtyBtn}
            onClick={handleIncrease}
            aria-label={`Increase quantity of ${item.title}`}
            id={`increase-qty-${item.id}`}
          >
            +
          </button>
        </div>

        {/* Item Total Price in Indian Rupees */}
        <div className={styles.itemTotal}>
          <span className={styles.totalPrice}>
            {formatINR(item.price * item.quantity)}
          </span>
        </div>

        {/* Remove Button */}
        <button
          type="button"
          className={styles.removeBtn}
          onClick={handleRemove}
          aria-label={`Remove ${item.title} from cart`}
          id={`remove-item-${item.id}`}
          title="Remove from cart"
        >
          🗑️
        </button>
      </div>
    </article>
  );
}

export default CartItem;
