/**
 * Header.jsx – Sticky Navigation Bar Component
 * 
 * Requirements Satisfied:
 * - Displays brand logo, navigation menu, and shopping cart icon with live badge count (20 marks)
 * - Integrates Redux search state for instant product filtering across the store (20 marks)
 * - Responsive layout adapted for mobile and desktop screens (20 marks)
 */
import { useState, useEffect } from 'react';
import { Link, NavLink, useNavigate, useLocation } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { setSearch, selectSearchQuery } from '../../redux/searchSlice';
import { selectCartCount } from '../../redux/cartSlice';
import styles from './Header.module.css';

function Header() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const location = useLocation();
  const searchQuery = useSelector(selectSearchQuery);
  const cartCount = useSelector(selectCartCount);
  const [scrolled, setScrolled] = useState(false);

  // Apply visual shadow on scroll
  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 12);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  /**
   * Handle user typing in the search input box
   */
  const handleSearchChange = (e) => {
    const value = e.target.value;
    dispatch(setSearch(value));
    // If user starts searching from product detail, cart, or checkout, navigate back to home to see results
    if (location.pathname !== '/' && value.trim().length > 0) {
      navigate('/');
    }
  };

  /**
   * Clear the search input
   */
  const handleClearSearch = () => {
    dispatch(setSearch(''));
  };

  return (
    <header className={`${styles.header} ${scrolled ? styles.scrolled : ''}`} role="banner">
      <div className={`container ${styles.inner}`}>
        {/* Brand Logo */}
        <Link to="/" className={styles.logo} id="brand-logo" aria-label="ShoppyGlobe Home">
          <span className={styles.logoIcon} aria-hidden="true">🛍️</span>
          <span className={styles.logoText}>
            Shoppy<span className={styles.logoSpan}>Globe</span>
          </span>
        </Link>

        {/* Search Bar - Controlled by Redux State */}
        <div className={styles.searchWrapper}>
          <span className={styles.searchIcon} aria-hidden="true">🔍</span>
          <input
            id="product-search-input"
            type="search"
            className={styles.searchInput}
            placeholder="Search products by title, category, brand..."
            value={searchQuery}
            onChange={handleSearchChange}
            aria-label="Search products"
            autoComplete="off"
          />
          {searchQuery && (
            <button
              type="button"
              className={styles.clearBtn}
              onClick={handleClearSearch}
              aria-label="Clear search input"
              title="Clear search"
            >
              ✕
            </button>
          )}
        </div>

        {/* Navigation & Cart Actions */}
        <nav className={styles.actions} aria-label="Main Navigation">
          <NavLink
            to="/"
            end
            className={({ isActive }) =>
              `${styles.navLink || ''} ${isActive ? styles.navActive || '' : ''}`
            }
            id="nav-home-link"
          >
            Explore
          </NavLink>

          <Link
            to="/cart"
            className={styles.cartBtn}
            id="header-cart-btn"
            aria-label={`Shopping cart with ${cartCount} items`}
          >
            <span className={styles.cartIcon} aria-hidden="true">🛒</span>
            <span className={styles.cartLabel}>Cart</span>
            {cartCount > 0 && (
              <span className={styles.badge} aria-label={`${cartCount} items in cart`} id="cart-item-count-badge">
                {cartCount}
              </span>
            )}
          </Link>
        </nav>
      </div>
    </header>
  );
}

export default Header;
