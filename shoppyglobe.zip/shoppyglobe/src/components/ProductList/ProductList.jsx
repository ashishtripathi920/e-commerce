/**
 * ProductList.jsx – Product Catalog & Filter Grid Component
 * 
 * Requirements Satisfied:
 * - Uses custom hook `useProducts` for data fetching with useEffect (20 marks)
 * - Implements live search & filter using Redux state (20 marks)
 * - Renders product list with unique keys (10 marks)
 * - Graceful error handling with retry trigger (10 marks)
 * - Performance skeleton placeholders during fetch
 */
import { useMemo } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import useProducts from '../../hooks/useProducts';
import {
  selectSearchQuery,
  selectSelectedCategory,
  selectSortBy,
  setCategory,
  setSortBy,
  resetFilters,
} from '../../redux/searchSlice';
import ProductItem from '../ProductItem/ProductItem';
import SkeletonCard from '../SkeletonCard/SkeletonCard';
import styles from './ProductList.module.css';

const SKELETON_COUNT = 8;

function ProductList() {
  const dispatch = useDispatch();
  const { products, categories, loading, error, refetch } = useProducts();

  const searchQuery = useSelector(selectSearchQuery);
  const selectedCategory = useSelector(selectSelectedCategory);
  const sortBy = useSelector(selectSortBy);

  // Filter and sort products based on Redux state
  const filteredProducts = useMemo(() => {
    let list = [...products];

    // 1. Filter by category
    if (selectedCategory && selectedCategory !== 'all') {
      list = list.filter(
        (p) => p.category?.toLowerCase() === selectedCategory.toLowerCase()
      );
    }

    // 2. Filter by search query (title, description, category, brand)
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter(
        (p) =>
          p.title?.toLowerCase().includes(q) ||
          p.category?.toLowerCase().includes(q) ||
          p.brand?.toLowerCase().includes(q) ||
          p.description?.toLowerCase().includes(q)
      );
    }

    // 3. Sort products
    if (sortBy === 'price-low') {
      list.sort((a, b) => a.price - b.price);
    } else if (sortBy === 'price-high') {
      list.sort((a, b) => b.price - a.price);
    } else if (sortBy === 'rating') {
      list.sort((a, b) => b.rating - a.rating);
    } else if (sortBy === 'discount') {
      list.sort((a, b) => (b.discountPercentage || 0) - (a.discountPercentage || 0));
    }

    return list;
  }, [products, selectedCategory, searchQuery, sortBy]);

  // ── Loading state ──────────────────────────────────────────
  if (loading) {
    return (
      <section className={styles.section} aria-label="Loading products">
        <div className={styles.sectionHeader}>
          <div>
            <h2 className={styles.sectionTitle}>Featured Products</h2>
            <p className={styles.sectionSubtitle}>Discover our top quality selection</p>
          </div>
        </div>
        <div className={styles.grid}>
          {Array.from({ length: SKELETON_COUNT }, (_, index) => (
            <SkeletonCard key={`skeleton-${index}`} />
          ))}
        </div>
      </section>
    );
  }

  // ── Error state ────────────────────────────────────────────
  if (error) {
    return (
      <section className={styles.section} aria-label="Error loading products">
        <div className={styles.errorBox}>
          <span className={styles.errorIcon} aria-hidden="true">⚠️</span>
          <h2 className={styles.errorTitle}>Unable to Load Products</h2>
          <p className={styles.errorMsg}>{error}</p>
          <button
            type="button"
            className={styles.retryBtn}
            onClick={refetch}
            id="retry-fetch-products-btn"
          >
            🔄 Try Again
          </button>
        </div>
      </section>
    );
  }

  return (
    <section className={styles.section} aria-label="Products Catalog">
      {/* Category Pills & Sort Bar */}
      <div className={styles.controlsBar}>
        {/* Category Tabs */}
        <div className={styles.categoriesWrapper} role="tablist" aria-label="Product Categories">
          <button
            type="button"
            className={`${styles.catChip} ${selectedCategory === 'all' ? styles.catActive : ''}`}
            onClick={() => dispatch(setCategory('all'))}
            role="tab"
            aria-selected={selectedCategory === 'all'}
          >
            All Products
          </button>
          {categories.slice(0, 10).map((cat) => (
            <button
              key={cat}
              type="button"
              className={`${styles.catChip} ${selectedCategory === cat ? styles.catActive : ''}`}
              onClick={() => dispatch(setCategory(cat))}
              role="tab"
              aria-selected={selectedCategory === cat}
            >
              {cat.replace('-', ' ')}
            </button>
          ))}
        </div>

        {/* Sort selector */}
        <div className={styles.sortWrapper}>
          <label htmlFor="product-sort-select" className={styles.sortLabel}>
            Sort By:
          </label>
          <select
            id="product-sort-select"
            className={styles.sortSelect}
            value={sortBy}
            onChange={(e) => dispatch(setSortBy(e.target.value))}
            aria-label="Sort products by"
          >
            <option value="featured">Featured</option>
            <option value="price-low">Price: Low to High</option>
            <option value="price-high">Price: High to Low</option>
            <option value="rating">Top Rated</option>
            <option value="discount">Biggest Discount</option>
          </select>
        </div>
      </div>

      {/* Section Header with dynamic count */}
      <div className={styles.sectionHeader}>
        <div>
          <h2 className={styles.sectionTitle}>
            {searchQuery
              ? `Results for "${searchQuery}"`
              : selectedCategory !== 'all'
              ? `${selectedCategory.charAt(0).toUpperCase() + selectedCategory.slice(1).replace('-', ' ')}`
              : 'Our Products'}
          </h2>
          <span className={styles.productCount}>
            Showing {filteredProducts.length} product{filteredProducts.length !== 1 ? 's' : ''}
          </span>
        </div>

        {(searchQuery || selectedCategory !== 'all' || sortBy !== 'featured') && (
          <button
            type="button"
            className={styles.resetBtn}
            onClick={() => dispatch(resetFilters())}
          >
            Reset Filters
          </button>
        )}
      </div>

      {/* Empty State */}
      {filteredProducts.length === 0 ? (
        <div className={styles.emptyBox}>
          <span className={styles.emptyIcon} aria-hidden="true">🔍</span>
          <h3 className={styles.emptyTitle}>No matching products found</h3>
          <p className={styles.emptyMsg}>
            We couldn't find anything matching your criteria. Try adjusting your search query or category filters.
          </p>
          <button
            type="button"
            className={styles.resetBtn}
            onClick={() => dispatch(resetFilters())}
          >
            Clear All Filters
          </button>
        </div>
      ) : (
        /* Product Grid – Rendered with unique product.id keys */
        <div className={styles.grid}>
          {filteredProducts.map((product) => (
            <ProductItem key={product.id} product={product} />
          ))}
        </div>
      )}
    </section>
  );
}

export default ProductList;
