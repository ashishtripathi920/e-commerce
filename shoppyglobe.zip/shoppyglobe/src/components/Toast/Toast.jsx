/**
 * Toast – context + component for global notifications
 * Usage: import { useToast } from './Toast'
 *        const toast = useToast();
 *        toast.success('Added to cart!');
 */
import { createContext, useContext, useState, useCallback } from 'react';
import styles from './Toast.module.css';

// ── Context ────────────────────────────────────────────────
const ToastContext = createContext(null);

let nextId = 0;

// ── Provider ───────────────────────────────────────────────
export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);

  const addToast = useCallback((message, type = 'info') => {
    const id = ++nextId;
    setToasts((prev) => [...prev, { id, message, type, exiting: false }]);

    // Auto-remove after 3s
    setTimeout(() => {
      setToasts((prev) =>
        prev.map((t) => (t.id === id ? { ...t, exiting: true } : t))
      );
      setTimeout(() => {
        setToasts((prev) => prev.filter((t) => t.id !== id));
      }, 280);
    }, 3000);
  }, []);

  const dismiss = useCallback((id) => {
    setToasts((prev) =>
      prev.map((t) => (t.id === id ? { ...t, exiting: true } : t))
    );
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 280);
  }, []);

  const toast = {
    success: (msg) => addToast(msg, 'success'),
    error:   (msg) => addToast(msg, 'error'),
    info:    (msg) => addToast(msg, 'info'),
  };

  const iconMap = { success: '✅', error: '❌', info: '🛒' };

  return (
    <ToastContext.Provider value={toast}>
      {children}
      <div className="toast-container">
        {toasts.map(({ id, message, type, exiting }) => (
          <div
            key={id}
            className={`${styles.toast} ${styles[type]} ${exiting ? styles.toastExiting : ''}`}
            role="alert"
            aria-live="polite"
          >
            <span className={styles.icon}>{iconMap[type]}</span>
            <span className={styles.message}>{message}</span>
            <button
              className={styles.close}
              onClick={() => dismiss(id)}
              aria-label="Dismiss notification"
            >
              ✕
            </button>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}

// ── Hook ───────────────────────────────────────────────────
export function useToast() {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error('useToast must be used within <ToastProvider>');
  return ctx;
}
