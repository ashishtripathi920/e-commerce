// SkeletonCard – animated placeholder card shown while products load
import styles from './SkeletonCard.module.css';

function SkeletonCard() {
  return (
    <div className={styles.card} aria-hidden="true">
      <div className={`${styles.image} skeleton`} />
      <div className={styles.body}>
        <div className={`${styles.badge} skeleton`} />
        <div className={`${styles.title} skeleton`} />
        <div className={`${styles.titleShort} skeleton`} />
        <div className={`${styles.rating} skeleton`} />
        <div className={`${styles.price} skeleton`} />
        <div className={`${styles.button} skeleton`} />
      </div>
    </div>
  );
}

export default SkeletonCard;
